import Reveal from "../components/Reveal";
import RisoImage from "../components/RisoImage";
import flowersPlate from "../assets/flowers.jpg";
import coffeePlate from "../assets/coffee.jpg";
import starsPlate from "../assets/stars.jpg";

const PLATES = [
  {
    src: flowersPlate,
    alt: "Risograph illustration of a wrapped bouquet of ranunculus",
    caption: "you + every flower stall we pass. I've started memorising the colours.",
    note: "plate 2",
    span: "lg:col-span-5",
    start: "",
    tilt: -2.6,
    pad: "lg:mt-0",
  },
  {
    src: coffeePlate,
    alt: "Risograph illustration seen from above of two coffee cups and a shared slice of cake",
    caption: "Sunday, 9:41am — you took the last bite again. I counted.",
    note: "plate 3",
    span: "lg:col-span-4",
    start: "lg:col-start-9",
    tilt: 3.2,
    pad: "lg:mt-24",
  },
  {
    src: starsPlate,
    alt: "Risograph illustration of a night sky of cut-paper stars above small hills",
    caption: "the night we stayed up just to see whether it would clear. it did.",
    note: "plate 4",
    span: "lg:col-span-6",
    start: "lg:col-start-3",
    tilt: -1.4,
    pad: "lg:-mt-8",
  },
];

export default function PasteUp() {
  return (
    <section className="scroll-mt-6 pt-24 sm:pt-32">
      <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b-2 border-ink pb-2 font-mono text-[10px] uppercase tracking-[0.28em] text-ink-soft sm:text-[11px]">
        <span className="text-ink">paste-up — plates 2 to 4</span>
        <span>held down with tape, not glue</span>
      </div>

      <div className="mt-4 flex items-end justify-between gap-6">
        <Reveal>
          <h2 className="max-w-[14ch] font-display text-[clamp(2.2rem,5.5vw,4rem)] font-black leading-[0.94] tracking-[-0.03em] riso-shadow-soft">
            Things I keep
            <br />
            looking at
          </h2>
        </Reveal>
        <Reveal delay={0.1} rotate={-3} className="hidden shrink-0 sm:block">
          <p className="font-hand text-2xl leading-tight text-riso-blue lg:text-3xl">
            ↓ three afternoons
            <br />
            I&rsquo;d re-run exactly
          </p>
        </Reveal>
      </div>

      <div className="mt-14 grid grid-cols-1 gap-y-16 sm:grid-cols-2 lg:grid-cols-12 lg:gap-x-6">
        {PLATES.map((p, i) => (
          <Reveal
            key={p.src}
            delay={i * 0.08}
            rotate={p.tilt}
            className={`${p.span} ${p.start} ${p.pad}`}
          >
            <figure className="relative">
              <span className={`tape -top-3 left-8 ${i % 2 ? "rotate-[4deg]" : "-rotate-6"}`} />
              <div className="border-2 border-ink bg-paper p-2.5 shadow-[8px_10px_0_rgba(46,38,32,0.16)] transition duration-300 hover:shadow-[10px_14px_0_rgba(26,95,208,0.35)]">
                <RisoImage
                  src={p.src}
                  alt={p.alt}
                  className="aspect-[3/2] w-full object-cover"
                  fallbackLabel={p.note}
                />
                <figcaption className="mt-3 flex items-start justify-between gap-4 px-1 pb-1">
                  <p className="font-hand text-xl leading-tight text-ink sm:text-2xl">{p.caption}</p>
                  <span className="mt-1 shrink-0 font-mono text-[9px] uppercase tracking-[0.2em] text-ink-soft">
                    {p.note}
                  </span>
                </figcaption>
              </div>
            </figure>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
