import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";

/** The wax-sealed envelope the whole zine lives inside. */
export default function Envelope({ onOpen }: { onOpen: () => void }) {
  const [cracked, setCracked] = useState(false);
  const reduce = useReducedMotion();

  const open = () => {
    if (cracked) return;
    setCracked(true);
    window.setTimeout(onOpen, reduce ? 60 : 950);
  };

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-8 bg-paper-deep px-5"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: reduce ? 1 : 1.07 }}
      transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
    >
      <p className="font-mono text-[10px] uppercase tracking-[0.42em] text-ink-soft sm:text-xs">
        special delivery · do not open until your birthday
      </p>

      <div style={{ perspective: 1200 }} className="w-full max-w-[540px]">
        <div className="relative aspect-[3/2] w-full rotate-[-1.4deg]" style={{ perspective: 1100 }}>
          {/* envelope body */}
          <div className="absolute inset-0 border-2 border-ink bg-paper shadow-[10px_12px_0_rgba(46,38,32,0.18)]" />

          {/* diagonal folds */}
          <svg
            viewBox="0 0 300 200"
            preserveAspectRatio="none"
            className="absolute inset-0 h-full w-full"
            aria-hidden="true"
          >
            <path d="M0 200 L150 104 L300 200" fill="none" stroke="#2E2620" strokeWidth="1.6" opacity="0.5" />
            <path d="M0 0 L150 104 L300 0" fill="none" stroke="#2E2620" strokeWidth="1.6" opacity="0.25" />
          </svg>

          {/* the letter, sliding up as it opens */}
          <motion.div
            className="absolute inset-x-8 top-7 h-[62%] border-2 border-ink bg-[#FFFCF2] px-5 py-4 shadow-[4px_5px_0_rgba(46,38,32,0.12)]"
            animate={cracked ? { y: -46, rotate: -2 } : { y: 0, rotate: 0 }}
            transition={{ type: "spring", stiffness: 90, damping: 14, delay: reduce ? 0 : 0.25 }}
          >
            <p className="font-hand text-2xl leading-tight text-riso-pink-dark sm:text-3xl">
              everything I couldn&rsquo;t say out loud,
              <br />
              printed twice so it would stay.
            </p>
            <div className="mt-3 h-px w-1/2 bg-ink/30" />
            <p className="mt-2 font-mono text-[9px] uppercase tracking-[0.3em] text-ink-soft">
              plate 1 of 1
            </p>
          </motion.div>

          {/* flap */}
          <motion.div
            className="absolute inset-x-0 top-0 h-1/2 origin-top"
            style={{ transformStyle: "preserve-3d" }}
            animate={cracked ? { rotateX: -168 } : { rotateX: 0 }}
            transition={{ duration: reduce ? 0.01 : 0.7, ease: [0.36, 0, 0.66, -0.4] }}
          >
            <svg
              viewBox="0 0 300 100"
              preserveAspectRatio="none"
              className="h-full w-full"
              aria-hidden="true"
            >
              <polygon points="0,0 300,0 150,100" fill="#E2D6BF" stroke="#2E2620" strokeWidth="2" />
            </svg>
          </motion.div>

          {/* wax seal */}
          <button
            type="button"
            onClick={open}
            disabled={cracked}
            aria-label="Break the seal and open your card"
            className="group absolute left-1/2 top-1/2 h-24 w-24 -translate-x-1/2 -translate-y-1/2 cursor-pointer rounded-full disabled:cursor-default sm:h-28 sm:w-28"
          >
            <motion.span
              className="absolute inset-y-0 left-0 w-1/2 rounded-l-full border-2 border-ink bg-riso-pink-dark"
              animate={cracked ? { x: -66, y: 54, rotate: -46, opacity: 0 } : { x: 0, y: 0, rotate: 0, opacity: 1 }}
              transition={{ duration: reduce ? 0.01 : 0.75, ease: "easeOut" }}
            />
            <motion.span
              className="absolute inset-y-0 right-0 w-1/2 rounded-r-full border-2 border-ink bg-riso-pink-dark"
              animate={cracked ? { x: 66, y: 58, rotate: 44, opacity: 0 } : { x: 0, y: 0, rotate: 0, opacity: 1 }}
              transition={{ duration: reduce ? 0.01 : 0.75, ease: "easeOut" }}
            />
            <motion.span
              className="pointer-events-none absolute inset-0 flex items-center justify-center text-paper"
              animate={cracked ? { opacity: 0, scale: 1.4 } : { opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <svg viewBox="0 0 40 40" className="h-10 w-10 sm:h-12 sm:w-12" aria-hidden="true">
                <path
                  d="M20 33C10 26.5 4 21.4 4 15.2 4 10.1 8 6.5 12.7 6.5c2.9 0 5.6 1.5 7.3 3.9 1.7-2.4 4.4-3.9 7.3-3.9C32 6.5 36 10.1 36 15.2c0 6.2-6 11.3-16 17.8Z"
                  fill="#F7F1E4"
                />
              </svg>
            </motion.span>
            <span className="pointer-events-none absolute inset-0 rounded-full ring-2 ring-offset-4 ring-offset-paper-deep ring-transparent transition group-hover:ring-riso-blue group-focus-visible:ring-riso-blue" />
          </button>
        </div>
      </div>

      <p
        className={`font-mono text-[11px] uppercase tracking-[0.34em] text-ink ${
          cracked ? "" : "blink"
        }`}
      >
        {cracked ? "opening…" : "tap the seal"}
      </p>
    </motion.div>
  );
}
