import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import RisoImage from "../components/RisoImage";
import cakePlate from "../assets/cake.jpg";

type Props = { name: string; setName: (v: string) => void };

export default function Cover({ name, setName }: Props) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(name);
  const reduce = useReducedMotion();

  const commit = () => {
    const next = draft.trim();
    setName(next.length ? next : "my love");
    setEditing(false);
  };

  return (
    <header className="relative">
      {/* running head */}
      <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b-2 border-ink pb-2 font-mono text-[10px] uppercase tracking-[0.28em] text-ink-soft sm:text-[11px]">
        <span className="text-ink">nº 01 — a zine for your birthday</span>
        <span>two inks · one copy</span>
        <span className="text-riso-pink-dark">press here ↓</span>
      </div>

      <div className="grid grid-cols-1 gap-10 pt-10 lg:grid-cols-12 lg:gap-8 lg:pt-14">
        <div className="lg:col-span-7">
          <motion.p
            initial={reduce ? false : { opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.5 }}
            className="mb-5 font-mono text-[11px] uppercase tracking-[0.4em] text-riso-blue"
          >
            printed in fluorescent pink + blue
          </motion.p>

          <h1 className="font-display font-black leading-[0.79] tracking-[-0.04em] text-[clamp(3.6rem,15vw,9rem)]">
            <motion.span
              className="riso-shadow block"
              initial={reduce ? false : { opacity: 0, y: 44, rotate: -3 }}
              animate={{ opacity: 1, y: 0, rotate: 0 }}
              transition={{ type: "spring", stiffness: 90, damping: 13, delay: 0.1 }}
            >
              HAPPY
            </motion.span>
            <motion.span
              className="riso-shadow block"
              initial={reduce ? false : { opacity: 0, y: 44, rotate: 2.5 }}
              animate={{ opacity: 1, y: 0, rotate: 0 }}
              transition={{ type: "spring", stiffness: 90, damping: 13, delay: 0.24 }}
            >
              BIRTH
            </motion.span>
            <motion.span
              className="riso-shadow block"
              initial={reduce ? false : { opacity: 0, y: 44, rotate: -2 }}
              animate={{ opacity: 1, y: 0, rotate: 0 }}
              transition={{ type: "spring", stiffness: 90, damping: 13, delay: 0.38 }}
            >
              DAY
            </motion.span>
          </h1>

          <div className="mt-7 flex flex-wrap items-end gap-x-4 gap-y-2">
            <span className="font-display text-2xl italic text-ink-soft">for</span>
            {editing ? (
              <input
                autoFocus
                value={draft}
                aria-label="Her name"
                onChange={(e) => setDraft(e.target.value)}
                onBlur={commit}
                onKeyDown={(e) => {
                  if (e.key === "Enter") commit();
                  if (e.key === "Escape") {
                    setDraft(name);
                    setEditing(false);
                  }
                }}
                className="min-w-0 flex-1 border-b-2 border-dashed border-riso-pink bg-transparent pb-1 font-hand text-[clamp(2.4rem,8vw,5rem)] leading-none text-riso-pink-dark outline-none"
                placeholder="her name"
              />
            ) : (
              <button
                type="button"
                onClick={() => {
                  setDraft(name);
                  setEditing(true);
                }}
                className="group text-left"
              >
                <span className="font-hand text-[clamp(2.6rem,8vw,5rem)] leading-none text-riso-pink-dark underline decoration-dashed decoration-riso-pink decoration-2 underline-offset-[10px] transition group-hover:text-riso-blue">
                  {name}
                </span>
              </button>
            )}
            {!editing && (
              <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-ink-soft">
                ✎ tap her name
              </span>
            )}
          </div>

          <p className="mt-8 max-w-[46ch] font-display text-lg leading-relaxed text-ink sm:text-xl">
            I couldn&rsquo;t decide between a card, a cake, or one very long text message —
            so I made all three, printed them in two inks and stapled them together.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-5">
            <a
              href="#reasons"
              className="border-2 border-ink bg-riso-pink px-7 py-3.5 font-mono text-xs uppercase tracking-[0.24em] text-ink shadow-[5px_5px_0_#2E2620] transition hover:-translate-y-0.5 hover:shadow-[7px_7px_0_#2E2620] active:translate-y-0.5 active:shadow-[3px_3px_0_#2E2620]"
            >
              open the first page →
            </a>
            <a
              href="#cake"
              className="border-b-2 border-dashed border-ink pb-0.5 font-mono text-xs uppercase tracking-[0.24em] text-ink-soft transition hover:text-riso-blue"
            >
              skip to the cake
            </a>
          </div>
        </div>

        {/* the pasted-in plate */}
        <motion.div
          initial={reduce ? false : { opacity: 0, y: 40, rotate: 6 }}
          animate={{ opacity: 1, y: 0, rotate: 2.2 }}
          transition={{ type: "spring", stiffness: 80, damping: 14, delay: 0.45 }}
          className="relative self-start lg:col-span-5 lg:mt-6"
        >
          <span className="tape -top-3 left-6 -rotate-6" />
          <span className="tape -bottom-3 right-4 rotate-3" />
          <div className="border-2 border-ink bg-paper p-3 shadow-[10px_12px_0_rgba(46,38,32,0.16)]">
            <RisoImage
              src={cakePlate}
              alt="Risograph illustration of a birthday cake with seven lit candles"
              className="aspect-[3/2] w-full object-cover"
              fallbackLabel="cake"
            />
            <div className="mt-3 flex items-baseline justify-between gap-3">
              <p className="font-hand text-xl leading-tight text-ink sm:text-2xl">
                seven candles, one for each reason —
              </p>
              <span className="font-mono text-[9px] uppercase tracking-[0.2em] text-ink-soft">
                plate 1
              </span>
            </div>
          </div>
        </motion.div>
      </div>
    </header>
  );
}
