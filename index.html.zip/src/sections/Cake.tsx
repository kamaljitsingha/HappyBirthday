import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";

const CENTERS = [209, 240, 271, 302, 333, 364, 395];
const FLAME_Y = 100;
const VW = 600;
const VH = 470;
const COLORS = ["#FF4D9D", "#1A5FD0", "#FFC400", "#C8205F", "#F7F1E4"];

/** Icing that drips over the edge of a tier. */
function scallop(x0: number, x1: number, y: number, step: number, drop: number) {
  let d = `M${x0} ${y} H${x1} V${y + 18}`;
  for (let x = x1; x - step >= x0; x -= step) {
    d += ` q${-step / 2} ${drop} ${-step} 0`;
  }
  return `${d} Z`;
}

function drawHeart(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, rot: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s, s);
  ctx.beginPath();
  ctx.moveTo(0, 0.35);
  ctx.bezierCurveTo(-0.95, -0.3, -0.55, -1.05, 0, -0.45);
  ctx.bezierCurveTo(0.55, -1.05, 0.95, -0.3, 0, 0.35);
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

function drawStar(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, rot: number) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s, s);
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const r = i % 2 === 0 ? 1 : 0.42;
    const a = (Math.PI / 5) * i - Math.PI / 2;
    const px = Math.cos(a) * r;
    const py = Math.sin(a) * r;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

export default function Cake() {
  const [lit, setLit] = useState<boolean[]>(() => CENTERS.map(() => true));
  const [wished, setWished] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number | null>(null);
  const reduce = useReducedMotion();

  const outCount = lit.filter((l) => !l).length;

  useEffect(() => {
    if (outCount === CENTERS.length) setWished(true);
  }, [outCount]);

  useEffect(() => {
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  const burst = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || reduce) return;
    const rect = canvas.getBoundingClientRect();
    if (rect.width < 4 || rect.height < 4) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(rect.width * dpr);
    canvas.height = Math.round(rect.height * dpr);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const W = rect.width;
    const H = rect.height;
    const ox = W / 2;
    const oy = H * 0.62;
    const parts = Array.from({ length: 140 }, () => {
      const a = -Math.PI / 2 + (Math.random() - 0.5) * 2.4;
      const sp = 5 + Math.random() * 11;
      return {
        x: ox + (Math.random() - 0.5) * 40,
        y: oy + (Math.random() - 0.5) * 30,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        rot: Math.random() * Math.PI,
        vr: (Math.random() - 0.5) * 0.24,
        s: 9 + Math.random() * 16,
        c: COLORS[Math.floor(Math.random() * COLORS.length)],
        shape: Math.random() > 0.45 ? 0 : 1,
      };
    });

    ctx.lineWidth = 1.4;
    const start = performance.now();

    const frame = (t: number) => {
      ctx.clearRect(0, 0, W, H);
      let alive = false;
      for (const p of parts) {
        p.vy += 0.16;
        p.vx *= 0.992;
        p.vy *= 0.992;
        p.x += p.vx;
        p.y += p.vy;
        p.rot += p.vr;
        if (p.y < H + 60 && p.x > -80 && p.x < W + 80) alive = true;
        ctx.fillStyle = p.c;
        ctx.strokeStyle = "rgba(46,38,32,0.55)";
        if (p.shape === 0) drawHeart(ctx, p.x, p.y, p.s / 22, p.rot);
        else drawStar(ctx, p.x, p.y, p.s / 20, p.rot);
      }
      if (alive && t - start < 4200) {
        rafRef.current = requestAnimationFrame(frame);
      } else {
        ctx.clearRect(0, 0, W, H);
        rafRef.current = null;
      }
    };
    rafRef.current = requestAnimationFrame(frame);
  }, [reduce]);

  const snuff = (i: number) =>
    setLit((prev) => {
      const next = [...prev];
      if (next[i]) next[i] = false;
      return next;
    });

  useEffect(() => {
    if (outCount === CENTERS.length) {
      const id = window.setTimeout(burst, 180);
      return () => window.clearTimeout(id);
    }
  }, [outCount, burst]);

  const relight = () => {
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    const c = canvasRef.current;
    const ctx = c?.getContext("2d");
    if (c && ctx) ctx.clearRect(0, 0, c.width, c.height);
    setWished(false);
    setLit(CENTERS.map(() => true));
  };

  return (
    <section
      id="cake"
      className="mt-28 scroll-mt-4 border-y-2 border-ink bg-paper-deep py-16 sm:mt-36 sm:py-20"
    >
      <div className="mx-auto w-full max-w-[1180px] px-5 sm:px-8">
        <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b-2 border-ink pb-2 font-mono text-[10px] uppercase tracking-[0.28em] text-ink-soft sm:text-[11px]">
          <span className="text-ink">the cake — seven candles</span>
          <span className="text-ink">tap each flame</span>
        </div>

        <div className="mt-10 grid items-center gap-10 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <h2 className="font-display text-[clamp(2.2rem,5vw,3.6rem)] font-black leading-[0.94] tracking-[-0.03em] riso-shadow-soft">
              Now close
              <br />
              your eyes
            </h2>
            <p className="mt-5 max-w-[34ch] font-display text-lg leading-relaxed text-ink">
              Seven flames. Snuff them one at a time, the way you&rsquo;re supposed to —
              one breath, one wish, no telling anyone what it was.
            </p>

            <div className="mt-7 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={() => setLit(CENTERS.map(() => false))}
                className="border-2 border-ink bg-paper px-5 py-3 font-mono text-[11px] uppercase tracking-[0.2em] text-ink shadow-[4px_4px_0_#2E2620] transition hover:-translate-y-0.5 hover:bg-riso-blue-light active:translate-y-0.5"
              >
                whoosh — blow them all out
              </button>
              <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-ink-soft tabular-nums">
                {String(outCount).padStart(2, "0")} / 07 out
              </span>
            </div>

            <AnimatePresence>
              {wished && (
                <motion.div
                  initial={reduce ? false : { opacity: 0, y: 18 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ delay: 0.35, duration: 0.6 }}
                  className="mt-8 border-l-4 border-riso-pink pl-5"
                >
                  <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-riso-blue">
                    the wish
                  </p>
                  <p className="mt-2 font-display text-xl italic leading-snug text-riso-pink-dark sm:text-2xl">
                    I wish you a life full of things that make you genuinely happy — and
                    countless reasons to smile.
                  </p>
                  <p className="mt-3 font-hand text-3xl leading-tight text-ink">
                    happy birthday, baby. ❤️
                  </p>
                  <button
                    type="button"
                    onClick={relight}
                    className="mt-4 border-b-2 border-dashed border-ink pb-0.5 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-soft transition hover:text-riso-blue"
                  >
                    ↺ light them again
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* the cake */}
          <div className="relative mx-auto w-full max-w-[560px] lg:col-span-8">
            <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 z-20 h-full w-full" />
            <svg viewBox={`0 0 ${VW} ${VH}`} className="relative h-auto w-full" role="img"
              aria-label="A three-tier birthday cake with seven candles">
              <defs>
                <path
                  id="flame"
                  d="M0 -25 C 13 -11, 18 1, 11 12 C 6 21, -6 21, -11 12 C -18 1, -13 -10, 0 -25 Z"
                />
                <pattern id="stripe" width="13" height="13" patternUnits="userSpaceOnUse" patternTransform="rotate(38)">
                  <rect width="13" height="13" fill="#F7F1E4" />
                  <rect width="6.5" height="13" fill="#FF4D9D" />
                </pattern>
              </defs>

              {/* table shadow */}
              <ellipse cx="300" cy="448" rx="250" ry="20" fill="#E2D6BF" />
              {/* plate */}
              <ellipse cx="300" cy="434" rx="244" ry="26" fill="#F7F1E4" stroke="#2E2620" strokeWidth="3" />
              <path d="M64 440 q236 34 472 0" fill="none" stroke="#2E2620" strokeWidth="2" opacity="0.4" />

              {/* bottom tier */}
              <rect x="88" y="316" width="424" height="112" rx="5" fill="#FFDCE9" stroke="#2E2620" strokeWidth="3" />
              <path d={scallop(88, 512, 316, 53, 22)} fill="#F7F1E4" stroke="#2E2620" strokeWidth="3" strokeLinejoin="round" />
              {/* middle tier */}
              <rect x="140" y="232" width="320" height="86" rx="5" fill="#D7E2FA" stroke="#2E2620" strokeWidth="3" />
              <path d={scallop(140, 460, 232, 40, 18)} fill="#F7F1E4" stroke="#2E2620" strokeWidth="3" strokeLinejoin="round" />
              {/* top tier */}
              <rect x="190" y="164" width="220" height="70" rx="5" fill="#FFDCE9" stroke="#2E2620" strokeWidth="3" />
              <path d={scallop(190, 410, 164, 44, 16)} fill="#F7F1E4" stroke="#2E2620" strokeWidth="3" strokeLinejoin="round" />

              {/* sprinkles */}
              {[
                [124, 352, "#1A5FD0"], [176, 388, "#FFC400"], [238, 344, "#1A5FD0"],
                [300, 392, "#C8205F"], [372, 350, "#FFC400"], [444, 386, "#1A5FD0"],
                [492, 348, "#C8205F"], [166, 268, "#FF4D9D"], [232, 292, "#1A5FD0"],
                [300, 264, "#FFC400"], [366, 294, "#C8205F"], [430, 268, "#1A5FD0"],
              ].map(([x, y, c], i) => (
                <rect key={i} x={x as number} y={y as number} width="16" height="5" rx="2.5"
                  fill={c as string} stroke="#2E2620" strokeWidth="1.2"
                  transform={`rotate(${(i * 37) % 90 - 45} ${x} ${y})`} />
              ))}

              {/* candles */}
              {CENTERS.map((cx, i) => (
                <g key={cx}>
                  <rect x={cx - 7} y={108} width="14" height="56" rx="3" fill="url(#stripe)" stroke="#2E2620" strokeWidth="2.5" />
                  <rect x={cx - 10} y={124} width="20" height="6" rx="1" fill="#1A5FD0" stroke="#2E2620" strokeWidth="1.5" />
                  {lit[i] ? (
                    <g transform={`translate(${cx} ${FLAME_Y})`}>
                      <g className="flicker" style={{ filter: "drop-shadow(0 0 9px rgba(255,196,0,0.85))" }}>
                        <use href="#flame" fill="#FFC400" stroke="#2E2620" strokeWidth="2" />
                        <path d="M0 -8 C 6 -2, 8 4, 4 9 C 1 12, -3 12, -5 8 C -9 3, -6 -3, 0 -8 Z" fill="#F7F1E4" />
                      </g>
                    </g>
                  ) : (
                    <circle key={`puff-${i}-${lit[i]}`} className="puff" cx={cx} cy={98} r="8" fill="#6B5D51" opacity="0.55" />
                  )}
                </g>
              ))}
            </svg>

            {/* flame hit targets */}
            {CENTERS.map((cx, i) =>
              lit[i] ? (
                <button
                  key={`btn-${cx}`}
                  type="button"
                  onClick={() => snuff(i)}
                  aria-label={`Blow out candle ${i + 1}`}
                  className="absolute z-30 w-[5%] -translate-x-1/2 cursor-pointer rounded-[3px] transition hover:bg-riso-yellow/30"
                  style={{ left: `${(cx / VW) * 100}%`, top: `${(74 / VH) * 100}%`, height: `${(91 / VH) * 100}%` }}
                />
              ) : null
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
