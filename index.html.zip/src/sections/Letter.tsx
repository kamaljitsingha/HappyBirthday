import Reveal from "../components/Reveal";

export default function Letter({ name }: { name: string }) {
  return (
    <section className="pt-24 sm:pt-32">
      <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b-2 border-ink pb-2 font-mono text-[10px] uppercase tracking-[0.28em] text-ink-soft sm:text-[11px]">
        <span className="text-ink">the letter</span>
        <span>written first, printed after</span>
      </div>

      {/* headline + standfirst */}
      <div className="mt-12 grid gap-8 lg:grid-cols-12">
        <Reveal className="lg:col-span-8">
          <h2 className="font-display text-[clamp(2.4rem,7vw,5rem)] font-black leading-[0.92] tracking-[-0.035em] riso-shadow-soft">
            Happy birthday,
            <br />
            my love <span className="text-riso-pink">❤️</span>
          </h2>
          <p className="mt-6 max-w-[52ch] font-display text-xl italic leading-relaxed text-ink sm:text-2xl">
            I honestly don&rsquo;t know how to write this without making it sound cheesy, but
            I&rsquo;ll just say what I feel.
          </p>
        </Reveal>

        <Reveal delay={0.12} rotate={-2.4} className="lg:col-span-4">
          <div className="ml-auto max-w-[300px] rotate-[-3deg] border-2 border-dashed border-riso-pink-dark px-5 py-4 text-center">
            <p className="font-mono text-[10px] uppercase leading-relaxed tracking-[0.24em] text-riso-pink-dark">
              printed at home
              <br />
              edition of 1
              <br />
              for {name}
            </p>
          </div>
        </Reveal>
      </div>

      {/* the body of the letter */}
      <Reveal delay={0.05}>
        <div className="mt-12 font-display text-[17px] leading-[1.75] text-ink sm:text-[18px] md:columns-2 md:gap-12">
          <p className="drop-cap mb-6">
            Having you in my life is something I&rsquo;m genuinely grateful for. You&rsquo;ve
            become such an important part of my days that sometimes I don&rsquo;t even realize
            how much you&rsquo;ve changed my life until I stop and think about it.
          </p>
          <p className="mb-6">
            I love the little things about you. The way you talk, the way you get annoyed, the
            random things you say, your smile, and even those moments when you&rsquo;re being
            impossible 😂. Somehow, all of it has become special to me.
          </p>
          <p className="mb-6">
            I know I&rsquo;m not perfect, and I might not always know exactly what to say or do.
            But one thing I want you to always know is that I care about you deeply. I want to
            see you happy, confident, successful, and proud of the person you become.
          </p>
          <p className="mb-6">
            On your birthday, I don&rsquo;t just wish you a good day. I wish you a life full of
            things that make you genuinely happy. I hope you achieve the things you secretly
            dream about, meet people who value you, and have countless reasons to smile.
          </p>
          <p className="mb-6">
            And selfishly, I hope I get to be there for many of those moments.
          </p>
          <p className="mb-6">
            Thank you for being you. Thank you for coming into my life and making it a little
            more beautiful.
          </p>
        </div>
      </Reveal>

      {/* sign-off */}
      <Reveal delay={0.08}>
        <div className="mt-8 border-t-2 border-ink pt-10">
          <p className="font-display text-[clamp(2rem,5.5vw,3.6rem)] font-black leading-[1] tracking-[-0.03em] riso-shadow-soft">
            Happy birthday, baby. <span className="text-riso-pink">❤️</span>
          </p>
          <p className="mt-6 max-w-[34ch] font-hand text-4xl leading-[1.15] text-riso-pink-dark sm:text-5xl">
            I love you, more than I probably know how to put into words.
          </p>
        </div>
      </Reveal>

      {/* colophon */}
      <Reveal delay={0.05}>
        <div className="mt-20 border-t-2 border-ink pt-6">
          <dl className="grid grid-cols-2 gap-x-6 gap-y-6 font-mono text-[11px] uppercase tracking-[0.16em] sm:grid-cols-4">
            {[
              ["inks", "Fluorescent Pink 1005 + Blue 1011"],
              ["stock", "120gsm warm white, uncoated"],
              ["edition", "1 of 1 — no reprints"],
              ["printed for", name],
            ].map(([k, v]) => (
              <div key={k}>
                <dt className="text-ink-soft">{k}</dt>
                <dd className="mt-1.5 text-ink first-letter:uppercase">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </Reveal>

      <footer className="mt-16 flex flex-wrap items-end justify-between gap-6 border-t-2 border-ink py-10">
        <p className="font-display text-[clamp(2.6rem,9vw,6rem)] font-black leading-[0.85] tracking-[-0.04em] riso-shadow">
          THE END
        </p>
        <div className="flex flex-col items-start gap-3">
          <a
            href="#top"
            className="border-2 border-ink bg-riso-blue px-6 py-3 font-mono text-[11px] uppercase tracking-[0.22em] text-paper shadow-[4px_4px_0_#2E2620] transition hover:-translate-y-0.5 hover:shadow-[6px_6px_0_#2E2620]"
          >
            ↑ back to page one
          </a>
          <p className="font-hand text-xl text-ink-soft">
            made at the kitchen table, badly, on purpose.
          </p>
        </div>
      </footer>
    </section>
  );
}
