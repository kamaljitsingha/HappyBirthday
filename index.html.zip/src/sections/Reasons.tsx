import Reveal from "../components/Reveal";

const REASONS = [
  "You laugh at the punchline before I finish it — and it still lands every time.",
  "You remember how I take my coffee, plus every order I only said once, by accident.",
  "You sing completely off-key in the car with total conviction. It's my favourite song now.",
  "You text “did you eat?” at exactly the hour I need it.",
  "You are kind to waiters, to strangers, to me on the days I'm least lovable.",
  "You fall asleep in the first ten minutes of the film, then ask what happened anyway.",
  "You make an ordinary Tuesday feel like something worth writing down.",
];

const TILT = [-2.4, 1.6, -1.2, 2.6, -1.8, 1.2, -2.8];

export default function Reasons() {
  return (
    <section id="reasons" className="scroll-mt-6 pt-24 sm:pt-32">
      <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 border-b-2 border-ink pb-2 font-mono text-[10px] uppercase tracking-[0.28em] text-ink-soft sm:text-[11px]">
        <span className="text-ink">the contents page — seven reasons</span>
        <span>tear along the dotted line</span>
      </div>

      <Reveal>
        <h2 className="mt-8 max-w-[16ch] font-display text-[clamp(2.4rem,6vw,4.4rem)] font-black leading-[0.92] tracking-[-0.03em] riso-shadow-soft">
          I&rsquo;d pick you again
        </h2>
      </Reveal>
      <Reveal delay={0.08}>
        <p className="mt-4 font-mono text-[11px] uppercase tracking-[0.3em] text-riso-blue">
          no. 01 — no. 07, in no particular order
        </p>
      </Reveal>

      <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
        {REASONS.map((reason, i) => (
          <Reveal key={reason} delay={i * 0.06} rotate={i % 3 === 1 ? 1.1 : i % 3 === 2 ? -1 : 0.7}>
            <article
              className="group relative flex h-full border-2 border-ink bg-paper shadow-[6px_7px_0_rgba(46,38,32,0.14)] transition duration-300 hover:-translate-y-2 hover:shadow-[9px_11px_0_rgba(255,77,157,0.45)]"
              style={{ rotate: `${TILT[i]}deg` }}
            >
              {/* stub */}
              <div className="flex w-16 shrink-0 flex-col items-center justify-between border-r-2 border-dashed border-ink bg-riso-blue-light py-4 sm:w-[68px]">
                <span className="font-mono text-[8px] uppercase tracking-[0.18em] text-riso-blue [writing-mode:vertical-rl]">
                  admit one
                </span>
                <span className="font-display text-3xl font-black tabular-nums leading-none text-riso-pink-dark sm:text-4xl">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>

              <div className="flex flex-1 flex-col justify-between gap-5 p-5">
                <p className="font-display text-[17px] leading-[1.5] text-ink sm:text-lg">{reason}</p>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[9px] uppercase tracking-[0.22em] text-ink-soft">
                    reason nº {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="halftone h-4 w-10 text-riso-pink opacity-70 transition group-hover:opacity-100" />
                </div>
              </div>
            </article>
          </Reveal>
        ))}

        <Reveal delay={0.42} rotate={2}>
          <div
            className="flex h-full flex-col items-start justify-center gap-3 border-2 border-dashed border-riso-pink-dark bg-riso-pink-light p-6"
            style={{ rotate: "2deg" }}
          >
            <span className="font-mono text-[9px] uppercase tracking-[0.24em] text-ink-soft">
              and the eighth, unnumbered
            </span>
            <p className="font-hand text-3xl leading-tight text-riso-pink-dark sm:text-4xl">
              because on the days nothing goes right, you&rsquo;re still the person I want
              sitting next to me.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
