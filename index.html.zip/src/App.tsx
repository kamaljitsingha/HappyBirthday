import { useEffect, useState } from "react";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import Spine from "./components/Spine";
import Envelope from "./sections/Envelope";
import Cover from "./sections/Cover";
import Reasons from "./sections/Reasons";
import PasteUp from "./sections/PasteUp";
import Cake from "./sections/Cake";
import Letter from "./sections/Letter";

const KEY = "riso-bday-name";

function readName(): string {
  try {
    const v = window.localStorage.getItem(KEY);
    return v && v.trim() ? v.trim() : "my love";
  } catch {
    return "my love";
  }
}

export default function App() {
  const [sealed, setSealed] = useState(true);
  const [name, setName] = useState(readName);

  useEffect(() => {
    document.body.style.overflow = sealed ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [sealed]);

  useEffect(() => {
    try {
      window.localStorage.setItem(KEY, name);
    } catch {
      /* private mode — the name simply won't persist */
    }
  }, [name]);

  const open = () => {
    setSealed(false);
    window.scrollTo(0, 0);
  };

  return (
    <MotionConfig reducedMotion="user">
    <div id="top" className="relative min-h-screen bg-paper text-ink">
      <div className="paper-grain" aria-hidden="true" />
      <Spine />

      <AnimatePresence>{sealed && <Envelope key="envelope" onOpen={open} />}</AnimatePresence>

      <motion.main
        className="md:pl-14"
        initial={false}
        animate={{ opacity: sealed ? 0 : 1, y: sealed ? 16 : 0 }}
        transition={{ duration: 0.7, delay: sealed ? 0 : 0.5, ease: [0.22, 1, 0.36, 1] }}
        style={{ visibility: sealed ? "hidden" : "visible" }}
      >
        <div className="mx-auto w-full max-w-[1180px] px-5 sm:px-8">
          <Cover name={name} setName={setName} />
          <Reasons />
          <PasteUp />
        </div>

        <Cake />

        <div className="mx-auto w-full max-w-[1180px] px-5 sm:px-8">
          <Letter name={name} />
        </div>
      </motion.main>
    </div>
    </MotionConfig>
  );
}
