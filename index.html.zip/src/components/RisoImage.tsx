import { useState } from "react";

type Props = {
  src: string;
  alt: string;
  className?: string;
  /** shown if the plate never arrives */
  fallbackLabel?: string;
};

/** A printed plate. If the image fails, we keep a designed halftone panel instead of a hole. */
export default function RisoImage({ src, alt, className = "", fallbackLabel = "plate" }: Props) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`halftone flex items-end bg-riso-pink-light p-4 text-riso-pink-dark ${className}`}
      >
        <span className="font-mono text-[10px] uppercase tracking-[0.2em]">{fallbackLabel} — ink only</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      decoding="async"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
