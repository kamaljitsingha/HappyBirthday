/** The stapled left edge of the zine — fixed, vertical, always with you. */
export default function Spine() {
  return (
    <aside
      aria-hidden="true"
      className="fixed left-0 top-0 z-40 hidden h-screen w-14 flex-col items-center justify-between border-r-2 border-ink bg-paper-deep py-6 md:flex"
    >
      <div className="flex flex-col items-center gap-5">
        <span className="staple" />
        <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-ink-soft">01</span>
      </div>

      <p className="vertical-rl max-h-[70vh] overflow-hidden rotate-180 whitespace-nowrap font-mono text-[10px] uppercase tracking-[0.3em] text-ink-soft">
        edition of one · printed with love
      </p>

      <div className="flex flex-col items-center gap-5">
        <span className="font-mono text-[9px] uppercase tracking-[0.3em] text-riso-pink-dark">riso</span>
        <span className="staple" />
      </div>
    </aside>
  );
}
