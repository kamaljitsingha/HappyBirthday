import { motion, useReducedMotion } from "framer-motion";
import type { ReactNode } from "react";

type Props = {
  children: ReactNode;
  className?: string;
  delay?: number;
  rotate?: number;
  y?: number;
};

/** A cut-out being placed on the page by hand: it drops, settles, slightly askew. */
export default function Reveal({
  children,
  className = "",
  delay = 0,
  rotate = 0,
  y = 30,
}: Props) {
  const reduce = useReducedMotion();

  if (reduce) {
    return (
      <div className={className} style={{ transform: rotate ? `rotate(${rotate}deg)` : undefined }}>
        {children}
      </div>
    );
  }

  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y, rotate: rotate - 1.6 }}
      whileInView={{ opacity: 1, y: 0, rotate }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ type: "spring", stiffness: 110, damping: 15, mass: 0.75, delay }}
    >
      {children}
    </motion.div>
  );
}
